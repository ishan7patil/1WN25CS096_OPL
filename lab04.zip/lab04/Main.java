import transaction.Account;
import reports.TransactionReport;
public class Main {
    public static void main(String[] args) {
        Account a = new Account(1001, 5000);
        System.out.println("Initial Balance: Rs. " + a.getBalance());
        a.deposit(2000);
        a.withdraw(2000);
        a.withdraw(20000);
        TransactionReport report = new TransactionReport();
        report.generateReport(a);
    }
}